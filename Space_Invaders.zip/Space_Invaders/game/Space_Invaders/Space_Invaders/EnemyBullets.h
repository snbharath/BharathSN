#ifndef _ENEMY_BULLETS_H_
#define _ENEMY_BULLETS_H_
#include <SFML/Graphics.hpp>
#include "SomeConstants.h"


class EnemyBullets
{
private:
	int m_DamageValue;
	Vector2f m_Position;
	int m_Width;
	int m_Height;
	sf::RectangleShape m_BulletBox;

public:
	EnemyBullets()
	{}

	EnemyBullets(Vector2f pos, ENEMY_TYPE type)
	{
		if( type == ENEMY_TYPE::TYPE2)
			m_DamageValue = BULLET_DAMAGE_COST * 2;
		else
			m_DamageValue = BULLET_DAMAGE_COST;

		m_Width = 3;
		m_Height = 10;
		m_BulletBox = sf::RectangleShape(Vector2f(m_Width, m_Height));
		m_BulletBox.setFillColor(Color::White);
		m_BulletBox.setPosition(Vector2f(pos.x+BULLET_ORIGIN_FIX, pos.y));
		m_Position = pos;
	}

	int renderBullet(sf::RenderWindow *window);
	
	int moveBullet(float deltaY);

	Vector2f getPosition();

	int getBulletDamage();
	
};

#endif