#ifndef _BACKGROUND_H_
#define _BACKGROUND_H_
#include <SFML/Graphics.hpp>
#include "SomeConstants.h"

class BackGround
{
private:
	sf::Texture m_BackgroundTex;
	sf::Sprite m_BackgroundSprite;

public:
	int createBackground();

	int renderBackground(sf::RenderWindow *window);
};


#endif