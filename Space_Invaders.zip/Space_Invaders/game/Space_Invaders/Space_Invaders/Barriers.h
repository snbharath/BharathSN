#ifndef _BARRIERS_H_
#define _BARRIERS_H_
#include <SFML/Graphics.hpp>
#include "SomeConstants.h"

class Barriers
{
private:
	/* Data Oriented Approach */
	int m_Health[NUMBER_OF_BARRIERS];
	Vector2f m_Position[NUMBER_OF_BARRIERS];
	sf::Texture m_BarrierTex[NUMBER_OF_BARRIERS];
	sf::Sprite m_BarrierSprite[NUMBER_OF_BARRIERS];
	Text m_Score[NUMBER_OF_BARRIERS];
	static sf::Font m_Font;

public:
	/* set font and Barrier size only once */
	static Vector2f m_BarrierSize ;
	static Vector2f m_BarrierScale ;


	static int setFontType();

	static int setBarrierSize();

	bool isAlive[NUMBER_OF_BARRIERS];

	Barriers(){}

	Barriers( Vector2f *pos, int val = BARRIERS_HEALTH)
	{
		for(int i=0; i< NUMBER_OF_BARRIERS ; i++)
		{
			m_Health[i] = val;
			m_Position[i] = pos[i];
			isAlive[i] = true;
		}
	}

	int createBarriers();

	int renderBarriers(sf::RenderWindow *window);

	Vector2f getPosition(int loc);

	int getHealth( int loc );

	int dealDamage( int toBarrier, int deltaHealth);
};

#endif