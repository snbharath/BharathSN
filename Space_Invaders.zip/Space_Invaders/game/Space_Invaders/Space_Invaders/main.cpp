#include <SFML/Graphics.hpp>
#include "SomeConstants.h"
#include "Barriers.h"
#include "PlayerMain.h"
#include "BackGround.h"
#include "Enemies.h"
#include "Bullets.h"
#include "EnemyBullets.h"
#include <SFML/Audio.hpp>

#include <sstream>
#include <iostream>
#include <fstream>

using namespace std;


bool enemyExistance[LEVEL1_ENEMY_TYPE1+LEVEL1_ENEMY_TYPE2];
bool barriersExistance[NUMBER_OF_BARRIERS];
bool enemyExistance2D[NUMBER_OF_ROWS_ENEMY][NUMBER_OF_COLUMNS_ENEMY];

Uint32 levelTotalScore = 0;
Uint32 hScoreInt = 0;
Uint32 playerHealth = PLAYER_HEALTH;
Uint32 currentNumberOfEnemies = LEVEL1_ENEMY_TYPE1+ LEVEL1_ENEMY_TYPE2;
Uint32 numberOfDeadEnemies = 0 ;
ENEMY_MOVEMENT_DIRECTION g_direction = ENEMY_MOVEMENT_DIRECTION::RIGHT;
sf::Clock playTime; 
float timeRecorded = 0;
Texture playerHealthTex;
Sprite PlayerHealthSprite;


template <class Temp>
bool checkCollisionToBlocks( Barriers *barriers, Temp bullet )
{
	for( int i=0; i<NUMBER_OF_BARRIERS; i++ )
	{
		if(barriersExistance[i])
		{
			Vector2f barrierPos = barriers->getPosition(i);
			Vector2f barrierSize = Barriers::m_BarrierSize;
			Vector2f bulletPos = bullet->getPosition();

			if( (bulletPos.x >= barrierPos.x) && (bulletPos.x <= barrierPos.x+barrierSize.x) && (bulletPos.y >= barrierPos.y) && ( bulletPos.y <= barrierPos.y+barrierSize.y) )
			{
				barriers->dealDamage(i, bullet->getBulletDamage());

				//Collision with a Barrier detected
				if(barriers->getHealth(i) <= 0)
				{
					barriersExistance[i] = false;
					barriers->isAlive[i] = false;
				}

				return true;

			}
		}
	}

	return false;
}

/****** No collision checking between the Rockets and bullets, as they cannot hit each other as per the requirement ******/ 
//bool checkBulletscollision(Bullets *playerBullet, EnemyBullets *enemyBullet)
//{
//	if( playerBullet && enemyBullet )
//	{
//		Vector2f playerBulletPos = playerBullet->getPosition();
//		Vector2f enemyBulletPos = enemyBullet->getPosition();
//		if( (playerBulletPos.x >= enemyBulletPos.x-4) && (playerBulletPos.x <= enemyBulletPos.x+4))
//		{
//			if( (playerBulletPos.y >= enemyBulletPos.y - 6) && ( playerBulletPos.y <= enemyBulletPos.y+6) )
//				return true;
//		}
//	}
//
//	return false;
//}

bool checkCollisionBetweenPlayerAndEnemy(PlayerMain *player, Enemies *enemy, int lastRow)
{
	if( player && enemy )
	{
		Vector2f playerPos = player->getPosition();
		bool isType2 = false;

		if( lastRow > 2 )
			 isType2 = true;

		for( int j=0; j<NUMBER_OF_COLUMNS_ENEMY; j++)
		{
			Vector2f enemyPos = enemy->getPosition(j);
			if(enemyExistance2D[lastRow][j])
			{
				//check the collision with all enemies
				if( (playerPos.x < enemyPos.x ) && ( playerPos.x+player->getPlayerSize().x > enemyPos.x ) )
				{
					if( (playerPos.y < enemyPos.y+Enemies::m_EnemySize.y) && ( playerPos.y+ player->getPosition().y > enemyPos.y+Enemies::m_EnemySize.y))
					{
						player->dealDamage(1);
						enemy->isAlive[isType2?((lastRow-2)*6+j):(lastRow*6+j)] = false;
						enemyExistance[lastRow*6+j] = false;
						enemyExistance2D[lastRow][j] = false;
						currentNumberOfEnemies--;
						numberOfDeadEnemies = ( TOTAL_NUMBER_OF_ENEMIES) - currentNumberOfEnemies;
						return true;
					}
				}
				else if(  (playerPos.x < enemyPos.x+ Enemies::m_EnemySize.x) && ( playerPos.x+ player->getPlayerSize().x > enemyPos.x+ Enemies::m_EnemySize.x ))
				{
					if( (playerPos.y < enemyPos.y+ Enemies::m_EnemySize.y) && ( playerPos.y + player->getPlayerSize().y > enemyPos.y+Enemies::m_EnemySize.y ))
					{
						player->dealDamage(1);
						enemy->isAlive[isType2?((lastRow-2)*6+j):(lastRow*6+j)] = false;
						enemyExistance[lastRow*6+j] = false;
						enemyExistance2D[lastRow][j] = false;
						currentNumberOfEnemies--;
						numberOfDeadEnemies = ( TOTAL_NUMBER_OF_ENEMIES) - currentNumberOfEnemies;
						return true;
					}
				}
				/*else if(  ( enemy))*/
			}
		}
	}

	return false;
}

bool checkCollisionToPlayer(PlayerMain *player, EnemyBullets *enemyBullet)
{
	Vector2f bulletPos = enemyBullet->getPosition();
	Vector2f playerPos = player->getPosition();
	Vector2f playerSize = player->getPlayerSize();

	if( (bulletPos.x >= playerPos.x) && (bulletPos.x <= playerPos.x+playerSize.x) && (bulletPos.y >= playerPos.y) && ( bulletPos.y <= playerPos.y+playerSize.y) )
	{
		player->dealDamage(1); //(enemyBullet->getBulletDamage() );
		return true;
	}
	else
		return false;
}

bool checkCollisionToEnemies( Enemies *enemy1List, Enemies *enemy2List, Vector2f bulletPos)
{
	for( int i=(TOTAL_NUMBER_OF_ENEMIES-1); i>=0; i-- )
	{
		if(enemyExistance[i])
		{
			ENEMY_TYPE typeOfEnemy;
			int enemyIndex;
			if( i > LEVEL1_ENEMY_TYPE1-1)
			{
				typeOfEnemy = ENEMY_TYPE::TYPE2;
				enemyIndex = i-LEVEL1_ENEMY_TYPE1;
			}
			else
			{
				typeOfEnemy = ENEMY_TYPE::TYPE1;
				enemyIndex = i;
			}

			// if Enemy exists, check for collision
			if( typeOfEnemy == ENEMY_TYPE::TYPE1)
			{
				//check for Enemy type 1 collision here
				Vector2f enemyPos = enemy1List->getPosition(enemyIndex);
				Vector2f enemySize = Enemies::getEnemySize();
				if( (bulletPos.x >= enemyPos.x) && (bulletPos.x <= enemyPos.x+enemySize.x) && (bulletPos.y >= enemyPos.y) && ( bulletPos.y <= enemyPos.y+enemySize.y) )
				{
					//Collision Detected
					levelTotalScore += SCORE_INCREMENTER*2;
					enemy1List->isAlive[enemyIndex] = false;
					enemyExistance[i] = false;
					enemyExistance2D[i/NUMBER_OF_COLUMNS_ENEMY][i%NUMBER_OF_COLUMNS_ENEMY] = false;
					currentNumberOfEnemies--;
					numberOfDeadEnemies = ( LEVEL1_ENEMY_TYPE1+ LEVEL1_ENEMY_TYPE2) - currentNumberOfEnemies;
					return true;
				}
			}
			else
			{
				// check for Enemy type 2 collision here
				Vector2f enemyPos = enemy2List->getPosition(enemyIndex);
				Vector2f enemySize = Enemies::getEnemySize();
				if( (bulletPos.x >= enemyPos.x) && (bulletPos.x <= enemyPos.x+enemySize.x) && (bulletPos.y >= enemyPos.y) && ( bulletPos.y <= enemyPos.y+enemySize.y) )
				{
					//Collision Detected
					levelTotalScore += SCORE_INCREMENTER;
					enemy2List->isAlive[enemyIndex] = false;
					enemyExistance[i] = false;
					enemyExistance2D[i/NUMBER_OF_COLUMNS_ENEMY][i%NUMBER_OF_COLUMNS_ENEMY] = false;
					currentNumberOfEnemies--;
					numberOfDeadEnemies = ( LEVEL1_ENEMY_TYPE1+ LEVEL1_ENEMY_TYPE2) - currentNumberOfEnemies;
					return true;
				}
			}
		}
	}

	return false;
}

int moveEnemies(Enemies *enemiesType1, Enemies *enemiesType2)
{
	int moveDown = 0;
	float timeSinceLastDown = playTime.getElapsedTime().asSeconds() - timeRecorded;
	if(timeSinceLastDown > TIME_TO_STEP_DOWN )
	{
		moveDown = ENEMYS_STEP_DOWN;
		timeRecorded = playTime.getElapsedTime().asSeconds();
	}
	//Moving emenies to the right
	if( (g_direction == ENEMY_MOVEMENT_DIRECTION::RIGHT) && (( Enemies::m_lastEnemyPos.x + ENEMY_DISPLACEMENT_VALUE + 30) < RIGHT_BOUND) ) // Constant 30 is to avoid enemy not to move out of the screen
	{
		for(int i=0; i<LEVEL1_ENEMY_TYPE1; i++)
			enemiesType1->setEnemyPosition( i, Vector2f ( enemiesType1->getPosition(i).x + ENEMY_DISPLACEMENT_VALUE + numberOfDeadEnemies, enemiesType1->getPosition(i).y + moveDown) );

		for(int i=0; i<LEVEL1_ENEMY_TYPE2; i++)
			enemiesType2->setEnemyPosition( i, Vector2f ( enemiesType2->getPosition(i).x + ENEMY_DISPLACEMENT_VALUE + numberOfDeadEnemies, enemiesType2->getPosition(i).y + moveDown) );
	}
	else
		g_direction = ENEMY_MOVEMENT_DIRECTION::LEFT;


	// moving enemies to the left
	if( (g_direction == ENEMY_MOVEMENT_DIRECTION::LEFT) && (( Enemies::m_firstEnemyPos.x - ENEMY_DISPLACEMENT_VALUE )> LEFT_BOUND) )
	{
		for(int i=0; i<LEVEL1_ENEMY_TYPE1; i++)
			enemiesType1->setEnemyPosition( i, Vector2f ( enemiesType1->getPosition(i).x - ENEMY_DISPLACEMENT_VALUE - numberOfDeadEnemies, enemiesType1->getPosition(i).y + moveDown) );

		for(int i=0; i<LEVEL1_ENEMY_TYPE2; i++)
			enemiesType2->setEnemyPosition( i, Vector2f ( enemiesType2->getPosition(i).x - ENEMY_DISPLACEMENT_VALUE - numberOfDeadEnemies, enemiesType2->getPosition(i).y + moveDown) );
	}
	else
		g_direction = ENEMY_MOVEMENT_DIRECTION::RIGHT;


	return 0;
}

int displayExit( sf::RenderWindow *window )
{
	sf::RectangleShape upperLine(sf::Vector2f(980,3));
	sf::RectangleShape lowerLine(sf::Vector2f(980,3));
	sf::RectangleShape leftMargin(sf::Vector2f(3,550));
	sf::RectangleShape rightMargin(sf::Vector2f(3,550));
	sf::RectangleShape playerDeck(sf::Vector2f(920,10));


	upperLine.setFillColor(Color::Green);
	lowerLine.setFillColor(Color::Green);
	leftMargin.setFillColor(Color::Green);
	rightMargin.setFillColor(Color::Green);
	playerDeck.setFillColor(Color::Green);

	upperLine.setPosition(10,50);
	lowerLine.setPosition(10,650);
	leftMargin.setPosition(30,80);
	rightMargin.setPosition(970,80);
	playerDeck.setPosition(40,630);

	sf::Font font;
	font.loadFromFile("C:\\Windows\\Fonts\\arial.ttf");

	std::stringstream ssScore;
	ssScore<<levelTotalScore;

	// Draw scores here
	Text score;
	score.setFont(font);
	score.setCharacterSize(30);
	score.setColor(sf::Color::Red);
	score.setPosition(LEFT_BOUND + 10, UPPER_BOUND + 10);
	if(hScoreInt < levelTotalScore)
	{
		sf::String scoreString = L"Your New High Score : ";
		scoreString = scoreString +sf::String(ssScore.str().c_str());
		score.setString(scoreString.toUtf32());
	}
	else
	{
		sf::String scoreString = L"Your Score : ";
		scoreString = scoreString +sf::String(ssScore.str().c_str());
		score.setString(scoreString.toUtf32());
	}
	



	// win or loose message here
	Text winOrLoose;
	winOrLoose.setFont(font);
	winOrLoose.setCharacterSize(30);
	winOrLoose.setColor(sf::Color::Red);
	winOrLoose.setPosition(LEFT_BOUND + 10, UPPER_BOUND + 60);
	if( playerHealth <=0)
	{
		sf::String msgString = L"Sorry! You lost the game. Better Luck next time!";
		winOrLoose.setString(msgString.toUtf32());
	}
	else
	{
		sf::String msgString = L"Congrats! you won the game!";
		winOrLoose.setString(msgString.toUtf32());
	}

	//Draw all entities to the renderer
	window->draw(upperLine);
	window->draw(lowerLine);
	window->draw(leftMargin);
	window->draw(rightMargin);
	window->draw(playerDeck);
	window->draw(score);
	window->draw(winOrLoose);

	return 0;
}

int drawLayout(sf::RenderWindow *window)
{
	sf::RectangleShape upperLine(sf::Vector2f(980,3));
	sf::RectangleShape lowerLine(sf::Vector2f(980,3));
	sf::RectangleShape leftMargin(sf::Vector2f(3,550));
	sf::RectangleShape rightMargin(sf::Vector2f(3,550));
	sf::RectangleShape playerDeck(sf::Vector2f(920,10));
	//sf::RectangleShape downThreshold(sf::Vector2f( 920,1 ));
	
	//Draw Player health
	playerHealthTex.loadFromFile("..\\Assets\\Player.png");
	PlayerHealthSprite.setTexture(playerHealthTex);
	PlayerHealthSprite.setScale( 0.4, 0.4 );

	upperLine.setFillColor(Color::Green);
	lowerLine.setFillColor(Color::Green);
	leftMargin.setFillColor(Color::Green);
	rightMargin.setFillColor(Color::Green);
	playerDeck.setFillColor(Color::Green);
	//downThreshold.setFillColor(Color::Cyan);

	upperLine.setPosition(10,50);
	lowerLine.setPosition(10,650);
	leftMargin.setPosition(30,80);
	rightMargin.setPosition(970,80);
	playerDeck.setPosition(40,630);
	//downThreshold.setPosition(40,ENEMYS_VERTICAL_THRESHOLD+80);
	//downThreshold.setOutlineThickness(0.1);

	sf::Font font;
	font.loadFromFile("C:\\Windows\\Fonts\\arial.ttf");

	//Draw score here
	std::stringstream ssScore;
	ssScore<<levelTotalScore;

	Text score;
	sf::String scoreString = L"SCORE: ";
	scoreString = scoreString +sf::String(ssScore.str().c_str());
	score.setFont(font);
	score.setString(scoreString.toUtf32());
	score.setCharacterSize(30);
	score.setColor(sf::Color::Red);
	score.setPosition(10,10);

	// Draw High score here
	std::stringstream ssHScore;
	ssHScore<<hScoreInt;

	Text hScore;
	sf::String hScoreString = L"HIGH SCORE: ";
	hScoreString = hScoreString+ sf::String(ssHScore.str().c_str());
	hScore.setFont(font);
	hScore.setString(hScoreString.toUtf32());
	hScore.setCharacterSize(30);
	hScore.setColor(sf::Color::Red);
	hScore.setPosition(600,10);
	

	Text txtHealth;
	sf::String strHealth = L"Player Health: ";
	strHealth = strHealth;
	txtHealth.setFont(font);
	txtHealth.setString(strHealth.toUtf32());
	txtHealth.setCharacterSize(30);
	txtHealth.setColor(sf::Color::Red);
	txtHealth.setPosition(10,650);


	//Draw all entities to the renderer
	window->draw(upperLine);
	window->draw(lowerLine);
	window->draw(leftMargin);
	window->draw(rightMargin);
	window->draw(playerDeck);
	window->draw(score);
	window->draw(hScore);
	window->draw( txtHealth);
	//window->draw(downThreshold);

	//Draw player health images
	for(int i=0; i<playerHealth; i++)
	{
		PlayerHealthSprite.setPosition(Vector2f( 220 + 40*i , LOWER_BOUND+5));
		window->draw(PlayerHealthSprite);
	}
	return 0;
}

int spawnEnemies(Vector2f *enemyType1Pos, Vector2f *enemyType2Pos)
{
	//All about Creating Enemies 
	/************* creating Enemies **************************/

	/************** Creating Type 1 Enemies ******************/
	float xOffsetEnemy  = PLAY_SPACE_LENGTH/LEVEL1_ENEMY_TYPE1 + 50, yIncrements = 50, yOffsetEnemy =0;
	int xCounter =LEVEL1_ENEMY_TYPE1/2;
	Enemies::setEnemySize();

	bool isNextRow = false;
	// Creating TYPE1 Enemy co-ordinates. 
	for(int i=0; i<LEVEL1_ENEMY_TYPE1; i++)
	{
		if(i!=0 && i%xCounter==0)
		{
			yOffsetEnemy+= yIncrements;
			isNextRow = true;
		}
		enemyType1Pos[i] = Vector2f( xOffsetEnemy*( (isNextRow? i-xCounter:i) +1), ENEMY_TOP_Y_START + yOffsetEnemy );//, ENEMY_TYPE::TYPE1);
	}
	
	/*************** Type 1 enemy ends ***********************/

	isNextRow = false;
	yOffsetEnemy += yIncrements;
	xCounter =LEVEL1_ENEMY_TYPE2/2;

	/************** Creating Type 2 Enemies ******************/
	

	for(int i=0; i<LEVEL1_ENEMY_TYPE2; i++)
	{
		if(i!=0 && i%xCounter==0)
		{
			yOffsetEnemy += yIncrements;
			isNextRow = true; 
		}
		enemyType2Pos[i] = Vector2f(xOffsetEnemy*( (isNextRow? i-xCounter:i) +1), ENEMY_TOP_Y_START + yOffsetEnemy); //, ENEMY_TYPE::TYPE2);
	}

	

	/*************** Type 2 enemy ends ***********************/

	/************ creating Enemies end ***********************/

	return 0;
}

int main()
{
	sf::RenderWindow window(sf::VideoMode(WIDTH_RES, HEIGHT_RES), "Space Invaders - By BHARATH SN");
	window.setFramerateLimit(FRAME_RATE_LIMIT);


    PlayerMain *playerObj = new PlayerMain();
	BackGround *backGround = new BackGround();
	int leftIndex = 0, rightIndex = 5, downIndex = ( LEVEL1_ENEMY_TYPE1 + LEVEL1_ENEMY_TYPE2);
	sf::SoundBuffer shootBuffer;
	sf::Sound shootSound;

	sf::Music backgroundMusic;
	if(!backgroundMusic.openFromFile("..\\Assets\\InvadersTheme.wav"))
		return -1;
	backgroundMusic.setLoop(true);
	backgroundMusic.play();

	if( !shootBuffer.loadFromFile("..\\Assets\\shoot.wav"))
	{
		return -1;
	}
	shootSound.setBuffer(shootBuffer);

	//Read file
	std::ifstream file;
	file.open("..\\Assets\\score.txt");
	string scoreString;
	std::getline(file,scoreString);
	
	if(scoreString.length() != 0)
		hScoreInt = stoi(scoreString);
	file.close();
	// reading file ends here 




	//All about Creating Barriers
	/****************creating barriers *************************/
	float xOffset = PLAY_SPACE_LENGTH/NUMBER_OF_BARRIERS;
	Vector2f barriersPos[NUMBER_OF_BARRIERS]; // create barriers positions 
	Barriers::setFontType();
	Barriers::setBarrierSize();

	for(int i=0; i<NUMBER_OF_BARRIERS; i++)
	{
		barriersPos[i] = Vector2f(xOffset*(i+1)-150, HEIGHT_RES/2+150);
	}
	Barriers *barriers = new Barriers(barriersPos);

	/************** Creating Barriers end ********************/



	

	

	backGround->createBackground();

	playerObj->createPlayer();

	//Deploying Barriers
	barriers->createBarriers();
	for(int i=0; i<NUMBER_OF_BARRIERS; i++)
		barriersExistance[i] = true;

	int j=0; // bool setter for enemies existance
	for(int i=0 ; i<LEVEL1_ENEMY_TYPE1; i++, j++)
		enemyExistance[j] = true;


	//j = LEVEL1_ENEMY_TYPE1;
	for(int i=0; i<LEVEL1_ENEMY_TYPE2; i++, j++)
		enemyExistance[j] = true;


	for(int i=0; i< 4; i++)
		for(int j=0; j<6; j++)
			enemyExistance2D[i][j] = true;


	Bullets *bulletObj;
	bulletObj=NULL;

	EnemyBullets *enemy1BulletObj, *enemy2BulletObj;
	enemy1BulletObj = NULL;
	enemy2BulletObj = NULL;
	
	Vector2f *enemyType1Pos = new Vector2f[LEVEL1_ENEMY_TYPE1];
	Vector2f *enemyType2Pos = new Vector2f[LEVEL1_ENEMY_TYPE2];

	spawnEnemies(enemyType1Pos, enemyType2Pos);

	Enemies *enemiesType1 = new Enemies(enemyType1Pos, ENEMY_TYPE::TYPE1);
	Enemies *enemiesType2 = new Enemies(enemyType2Pos, ENEMY_TYPE::TYPE2);
	//spawning enemies
	enemiesType1->createEnemy();
	enemiesType2->createEnemy();
	
	
	// Game Loop starts here
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
			{
				if(hScoreInt < levelTotalScore)
				{
					std::ofstream file;
					file.open("..\\Assets\\score.txt",std::fstream::out);
					string scoreString;
					std::stringstream sshighScore;
					sshighScore<<levelTotalScore;
					file << sshighScore.str().c_str();
				}
                window.close();
			}
		}

		window.clear();

		if( currentNumberOfEnemies<=0)
		{

			delete ( enemyType1Pos );
			delete ( enemyType2Pos );
			delete ( enemiesType1 );
			delete ( enemiesType2 );

			enemyType1Pos = new Vector2f[LEVEL1_ENEMY_TYPE1];
			enemyType2Pos = new Vector2f[LEVEL1_ENEMY_TYPE2];

			spawnEnemies(enemyType1Pos, enemyType2Pos);

			enemiesType1 = new Enemies(enemyType1Pos, ENEMY_TYPE::TYPE1);
			enemiesType2 = new Enemies(enemyType2Pos, ENEMY_TYPE::TYPE2);
			//spawning enemies
			enemiesType1->createEnemy();
			enemiesType2->createEnemy();

			currentNumberOfEnemies = TOTAL_NUMBER_OF_ENEMIES;
			numberOfDeadEnemies = 0;

			int j=0; // bool setter for enemies existance
	for(int i=0 ; i<LEVEL1_ENEMY_TYPE1; i++, j++)
		enemyExistance[j] = true;


	//j = LEVEL1_ENEMY_TYPE1;
	for(int i=0; i<LEVEL1_ENEMY_TYPE2; i++, j++)
		enemyExistance[j] = true;


	for(int i=0; i< 4; i++)
		for(int j=0; j<6; j++)
			enemyExistance2D[i][j] = true;
		}
		
		if( playerHealth <= 0 )
		{
			//handle exit process here
			displayExit(&window);
		}
		else
		{
		backGround->renderBackground(&window);
		drawLayout(&window);
		
		//this is for getting the boundaries of enemies
		for(int i=0; i<NUMBER_OF_COLUMNS_ENEMY; i++){
		for(int j=0; j<NUMBER_OF_ROWS_ENEMY; j++){
		if(enemyExistance2D[j][i])
		{
			leftIndex =  i;
			i=NUMBER_OF_COLUMNS_ENEMY; // just to exit out of the first for loop
			break;
		}}}
		
		for(int i=NUMBER_OF_COLUMNS_ENEMY-1; i>=0; i--){
		for(int j=0; j<NUMBER_OF_ROWS_ENEMY; j++){
		if(enemyExistance2D[j][i])
		{
			rightIndex = i;
			i=-1;  // just to exit out of the first for loop
			break;
		}}}

		for(int i=NUMBER_OF_ROWS_ENEMY-1; i>=0; i--){
		for(int j=NUMBER_OF_COLUMNS_ENEMY-1; j>=0; j--){
		if(enemyExistance2D[i][j])
		{
			downIndex = i;
			i = -1;
			break;
		}}}

		Enemies::m_firstEnemyPos = enemiesType1->getPosition( leftIndex );
		Enemies::m_lastEnemyPos = enemiesType2->getPosition( rightIndex );
		
		if( downIndex < 2)
			Enemies::m_downLastEnemyPos = enemiesType1->getPosition(downIndex);
		else
			Enemies::m_downLastEnemyPos = enemiesType2->getPosition(downIndex);


		//moving enemies to and fro
		moveEnemies(enemiesType1, enemiesType2);

		
		playerHealth = playerObj->getPlayerHealth();

		//render player
		playerObj->renderPlayer(&window);

		//Render Barriers
		barriers->renderBarriers(&window);

		//Render Enemies
		enemiesType1->renderEnemy(&window);
		enemiesType2->renderEnemy(&window);

		
		if( Enemies::m_downLastEnemyPos.y > ENEMYS_VERTICAL_THRESHOLD )
		{
			playerObj->dealDamage(1);//(playerObj->getPlayerHealth());
			playerHealth = playerObj->getPlayerHealth();
		}
		// Player bullet to Barriers and Emenies

		checkCollisionBetweenPlayerAndEnemy(playerObj, (downIndex < 2)?enemiesType1:enemiesType2, downIndex);
		

		if(bulletObj != NULL)
		{
			if(  checkCollisionToEnemies(enemiesType1, enemiesType2, bulletObj->getPosition()) || checkCollisionToBlocks<Bullets*>( barriers, bulletObj) || bulletObj->getPosition().y < UPPER_BOUND)
			{
				free(bulletObj);
				bulletObj = NULL;
			}
			/*else if(bulletObj->getPosition().y < UPPER_BOUND)
			{
				free(bulletObj);
				bulletObj = NULL;
			}*/
			else
			{
				bulletObj->moveBullet(-BULLET_SPEED);
				bulletObj->renderBullet(&window);
			}
		}

		
		// Enemy1 bullets to Barriers and Player
		if(enemy1BulletObj != NULL)
		{
			bool isABulletCollision = false;
			if(  checkCollisionToPlayer(playerObj, enemy1BulletObj) || checkCollisionToBlocks<EnemyBullets*>( barriers, enemy1BulletObj) || enemy1BulletObj->getPosition().y > LOWER_BOUND - 35/*||( isABulletCollision = checkBulletscollision(bulletObj, enemy1BulletObj))*/ )
			{		
				free(enemy1BulletObj);
				enemy1BulletObj = NULL;

				/*if( isABulletCollision && bulletObj )
				{
					levelTotalScore += BULLET_POINTS_ENEMY1;
					free(bulletObj);
					bulletObj = NULL;
				}*/
			}
			else
			{
				enemy1BulletObj->moveBullet(BULLET_SPEED);
				enemy1BulletObj->renderBullet(&window);
			}
		}
		else
		{
			int randIndex = rand()%LEVEL1_ENEMY_TYPE1;
			if(enemiesType1->isAlive[randIndex])
			{
				enemy1BulletObj = new EnemyBullets(enemiesType1->getPosition(randIndex), ENEMY_TYPE::TYPE1);
				enemy1BulletObj->renderBullet(&window);
			}
		}

		// Enemy2 bullets to Barriers and Player
		if(enemy2BulletObj != NULL)
		{
			bool isABulletCollision = false;
			if( checkCollisionToPlayer(playerObj, enemy2BulletObj) || checkCollisionToBlocks<EnemyBullets*>( barriers, enemy2BulletObj) || enemy2BulletObj->getPosition().y > LOWER_BOUND - 35 /*|| ( isABulletCollision = checkBulletscollision(bulletObj, enemy2BulletObj))*/ )
			{
				free(enemy2BulletObj);
				enemy2BulletObj = NULL;

				/*if( isABulletCollision && bulletObj )
				{
					levelTotalScore += BULLET_POINTS_ENEMY2;
					free(bulletObj);
					bulletObj = NULL;
				}*/
			}
			else
			{
				enemy2BulletObj->moveBullet(BULLET_SPEED);
				enemy2BulletObj->renderBullet(&window);
			}
		}
		else
		{
			int randIndex = rand()%LEVEL1_ENEMY_TYPE2;
			if(enemiesType2->isAlive[randIndex])
			{
				enemy2BulletObj = new EnemyBullets(enemiesType2->getPosition(randIndex), ENEMY_TYPE::TYPE2);
				enemy2BulletObj->renderBullet(&window);
			}
		}


		if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
		{
			playerObj->movePlayer(-PLAYER_MOVEMENT_X_OFFSET);
		}
		if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
		{
			playerObj->movePlayer(PLAYER_MOVEMENT_X_OFFSET);
		}
		if(bulletObj==NULL && sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
		{
			shootSound.play();
			bulletObj = new Bullets(playerObj->getPosition());
			bulletObj->renderBullet(&window);
		}
		}
		
		window.display();
    }

    return 0;
}