#include "Bullets.h"

int Bullets::renderBullet(sf::RenderWindow *window)
{
	window->draw(m_BulletBox);
	return 0;
}

int Bullets::moveBullet(float deltaY)
{
	Vector2f pos = m_BulletBox.getPosition();
	m_Position = Vector2f(pos.x,pos.y+deltaY);
	m_BulletBox.setPosition(m_Position);
	return 0;
}

Vector2f Bullets::getPosition()
{
	return m_Position;
}

int Bullets::getBulletDamage()
{
	return m_DamageValue;
}