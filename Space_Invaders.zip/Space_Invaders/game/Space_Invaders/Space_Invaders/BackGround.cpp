#include "BackGround.h"


int BackGround::createBackground()
{
	m_BackgroundTex.loadFromFile("..\\Assets\\background.jpg");
	m_BackgroundSprite.setTexture(m_BackgroundTex);
	m_BackgroundSprite.setScale(0.521,0.65);

	return 0;
}

int BackGround::renderBackground(sf::RenderWindow *window)
{
	window->draw(m_BackgroundSprite);
	return 0;
}