#include "Enemies.h"

int Enemies::createEnemy()
{
	for ( int i = 0; i< LEVEL1_ENEMY_TYPE1; i++ )
	{
		if( m_Type[i] == ENEMY_TYPE::TYPE1)
			m_EnemyTex[i].loadFromFile("..\\Assets\\enemy1.png");
		else
			m_EnemyTex[i].loadFromFile("..\\Assets\\enemy2.png");

	
		m_EnemySprite[i].setTexture(m_EnemyTex[i]);
		m_EnemySprite[i].setScale( m_EnemyScale );
		m_EnemySprite[i].setPosition(m_Position[i]);
	}
	return 0;
}


Vector2f Enemies::m_EnemyScale = Vector2f(0.2,0.15);

Vector2f Enemies::m_EnemySize = Vector2f(0.0f, 0.0f);


Vector2f Enemies::getEnemySize()
{
	return m_EnemySize;
}

int Enemies::renderEnemy(sf::RenderWindow *window)
{
	for( int i=0 ; i < LEVEL1_ENEMY_TYPE1; i++ )
	{
		if(this->isAlive[i])
			window->draw(m_EnemySprite[i]);
	}
	return 0;
}

Vector2f Enemies::getPosition( int loc )
{
	return m_Position[loc];
}

Vector2f Enemies::m_firstEnemyPos = Vector2f(0.0f,0.0f);

Vector2f Enemies::m_lastEnemyPos = Vector2f(0.0f,0.0f);

Vector2f Enemies::m_downLastEnemyPos = Vector2f(0.0f, 0.0f);

int Enemies::setEnemyPosition(int loc, Vector2f pos)
{
	m_Position[loc] = pos;
	m_EnemySprite[loc].setPosition(m_Position[loc]);

	return 0;
}

int Enemies::setEnemySize()
{
	Texture *temp = new Texture();
	temp->loadFromFile("..\\Assets\\enemy1.png"); // even enemy type 2 would also do here

	m_EnemySize = Vector2f(temp->getSize().x * m_EnemyScale.x, temp->getSize().y * m_EnemyScale.y);

	delete temp;

	return 0;
}