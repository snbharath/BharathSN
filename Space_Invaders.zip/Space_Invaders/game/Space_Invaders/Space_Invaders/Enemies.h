#ifndef _ENEMIES_H_
#define _ENEMIES_H_
#include <SFML/Graphics.hpp>
#include "SomeConstants.h"

class Enemies
{
private:
	/****************** Data Oriented Approach ********************/
	int m_Health[LEVEL1_ENEMY_TYPE1];
	ENEMY_TYPE m_Type[LEVEL1_ENEMY_TYPE1];
	Vector2f m_Position[LEVEL1_ENEMY_TYPE1];
	sf::Texture m_EnemyTex[LEVEL1_ENEMY_TYPE1];
	sf::Sprite m_EnemySprite[LEVEL1_ENEMY_TYPE1];

public:
	bool isAlive[LEVEL1_ENEMY_TYPE1];
	static Vector2f m_firstEnemyPos;
	static Vector2f m_lastEnemyPos;
	static Vector2f m_downLastEnemyPos;
	static Vector2f m_EnemySize ;
	static Vector2f m_EnemyScale ;

	static int setEnemySize();
	static Vector2f getEnemySize();

	Enemies() {}

	Enemies( Vector2f *pos, ENEMY_TYPE type, int val = ENEMIES_HEALTH )
	{
		for(int i = 0; i < LEVEL1_ENEMY_TYPE1 ; i++ )
		{
			m_Type[i] = type;
			if(m_Type[i] == ENEMY_TYPE::TYPE1)
				m_Health[i] = val*2;
			else
				m_Health[i] = val;

			m_Position[i] = pos[i];

			isAlive[i] = true;
		}
	}


	int createEnemy();

	int renderEnemy(sf::RenderWindow *window);

	Vector2f getPosition( int loc );

	int setEnemyPosition( int loc, Vector2f pos );
};

#endif