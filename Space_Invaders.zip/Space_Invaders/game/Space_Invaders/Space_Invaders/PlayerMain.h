#ifndef _PLAYER_MAIN_H_
#define _PLAYER_MAIN_H_
#include <SFML/Graphics.hpp>
#include "SomeConstants.h"


class PlayerMain
{
private:
	int m_Health;
	Vector2f m_Position;
	float m_FixedVerticle;
	sf::Texture m_PlayerTex;
	sf::Sprite m_PlayerSprite;
	Vector2f m_PlayerSize;

public:

	PlayerMain(int val = PLAYER_HEALTH)
	{
		m_Health = val;
		m_FixedVerticle = HEIGHT_RES/2+240;
		//position = Vector2f(WIDTH_RES/2, fixedVerticle);
		m_Position = Vector2f((RIGHT_BOUND-LEFT_BOUND)/2, m_FixedVerticle);
	}

	int createPlayer();

	int renderPlayer(sf::RenderWindow *window);

	int movePlayer(float deltaX);

	Vector2f getPosition();

	int getPlayerHealth();

	void setSizeOfTexture();

	Vector2f getPlayerSize();

	int dealDamage(int deltaHealth);
};

#endif