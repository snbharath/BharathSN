#include "PlayerMain.h"


int PlayerMain::createPlayer()
{
	m_PlayerTex.loadFromFile("..\\Assets\\Player.png");

	m_PlayerSprite.setTexture(m_PlayerTex);
	m_PlayerSprite.setScale(0.5,0.5);
	m_PlayerSprite.setPosition(m_Position);

	setSizeOfTexture();

	return 0;
}

int PlayerMain::renderPlayer(sf::RenderWindow *window)
{
	window->draw(m_PlayerSprite);

	return 0;
}

int PlayerMain::movePlayer( float deltaX )
{

	m_Position.x += deltaX;

	if(m_Position.x > RIGHT_BOUND || m_Position.x < LEFT_BOUND)
	{
		m_Position.x -= deltaX;
	}
	else
	{
		m_Position.x +=deltaX;
		m_PlayerSprite.setPosition(m_Position);
	}
	return 0;
}

Vector2f PlayerMain::getPosition()
{
	return m_Position;
}

int PlayerMain::getPlayerHealth()
{
	return m_Health;
}

void PlayerMain::setSizeOfTexture()
{
	Vector2f scale = m_PlayerSprite.getScale();
	Vector2u size = m_PlayerTex.getSize();

	m_PlayerSize = Vector2f( (scale.x*size.x), (scale.y*size.y));
}

Vector2f PlayerMain::getPlayerSize()
{
	return m_PlayerSize;
}

int PlayerMain::dealDamage( int deltaHealth )
{
	m_Health -= deltaHealth;

	return 0;
}