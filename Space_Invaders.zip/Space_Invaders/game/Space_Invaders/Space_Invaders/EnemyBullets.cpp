#include "EnemyBullets.h"

int EnemyBullets::renderBullet(sf::RenderWindow *window)
{
	window->draw(m_BulletBox);
	return 0;
}

int EnemyBullets::moveBullet(float deltaY)
{
	Vector2f pos = m_BulletBox.getPosition();
	m_Position = Vector2f(pos.x,pos.y+deltaY);
	m_BulletBox.setPosition(m_Position);
	return 0;
}

Vector2f EnemyBullets::getPosition()
{
	return m_Position;
}

int EnemyBullets::getBulletDamage()
{
	return m_DamageValue;
}