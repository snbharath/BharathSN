#include "Barriers.h"
#include <sstream>

int Barriers::createBarriers()
{
	for (int i=0; i< NUMBER_OF_BARRIERS ; i++)
	{	
		m_BarrierTex[i].loadFromFile("..\\Assets\\Barrier.png");

		m_BarrierSprite[i].setTexture(m_BarrierTex[i]);
		m_BarrierSprite[i].setScale( m_BarrierScale );
		m_BarrierSprite[i].setPosition(m_Position[i]);

		std::stringstream ss;
		ss<< BARRIERS_HEALTH;

		m_Score[i].setFont(m_Font);
		m_Score[i].setString(ss.str().c_str());
		m_Score[i].setCharacterSize(20);
		m_Score[i].setColor(sf::Color::Magenta);
		m_Score[i].setPosition(Vector2f(m_Position[i].x+30, m_Position[i].y+5));
	}

	return 0;
}

int Barriers::renderBarriers(sf::RenderWindow *window)
{
	for (int i=0; i< NUMBER_OF_BARRIERS ; i++)
	{
		if(isAlive[i])
		{
			window->draw(m_BarrierSprite[i]);
			window->draw(m_Score[i]);
		}
	}
	return 0;
}

Vector2f Barriers::getPosition(int loc)
{
	return m_Position[loc];
}

int Barriers::dealDamage( int toBarrier, int deltaHealth )
{
 	m_Health[toBarrier] -= deltaHealth;

	std::stringstream ss;
	ss<< m_Health[toBarrier];

	m_Score[toBarrier].setString(ss.str().c_str());

	return 0;
}

int Barriers::getHealth( int loc )
{
	return m_Health[loc];
}

Font Barriers::m_Font = Font();

Vector2f Barriers::m_BarrierSize = Vector2f(0.0f, 0.0f);

Vector2f Barriers::m_BarrierScale = Vector2f(0.2,0.15);

int Barriers::setFontType()
{
	m_Font.loadFromFile("C:\\Windows\\Fonts\\arial.ttf");

	return 0;
}

int Barriers::setBarrierSize()
{
	Texture *temp = new Texture();
	temp->loadFromFile("..\\Assets\\Barrier.png");

	m_BarrierSize = Vector2f(temp->getSize().x * m_BarrierScale.x, temp->getSize().y * m_BarrierScale.y);

	delete temp;

	return 0;
}