Steps to build this game

1) It needs visual studio 2010+ version installed 
2) Just Extract the folder and Navigate the Space_Invaders folders to open the solution(\game\Space_Invaders\Space_Invaders.sln) file.
3) Build the game on the platform of your preference.
4) All the build game binaries can be found in the bin folder.
5) Thanks for playing.
